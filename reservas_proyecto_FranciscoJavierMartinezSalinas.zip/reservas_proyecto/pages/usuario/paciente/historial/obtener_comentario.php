<?php
/*
 * Archivo que recibe un ID de cita (agenda_id) por GET,
 * y devuelve en formato JSON el estado de esa cita y sus comentarios asociados,
 * para mostrarlos en el modal del historial.
 */

include('../../../../includes/db.php');
header('Content-Type: application/json');

// Comprobar que se recibe el parámetro 'id' por GET
if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'ID de cita no especificado']);
    exit;
}

$agenda_id = $_GET['id'];

// Obtener el estado de la cita
$sql_estado = "SELECT estado FROM agenda WHERE id = ?";
$stmt_estado = $pdo->prepare($sql_estado);
$stmt_estado->execute([$agenda_id]);
$estado = $stmt_estado->fetchColumn();

if ($estado === false) {
    echo json_encode(['error' => 'Cita no encontrada']);
    exit;
}

// Obtener los comentarios de la cita
$sql_comentarios = "SELECT comentario, fecha_comentario 
                   FROM comentarios_agenda 
                   WHERE agenda_id = ? 
                   ORDER BY fecha_comentario DESC";
$stmt_comentarios = $pdo->prepare($sql_comentarios);
$stmt_comentarios->execute([$agenda_id]);
$comentarios = $stmt_comentarios->fetchAll(PDO::FETCH_ASSOC);

// Devolver JSON con estado y comentarios
echo json_encode([
    'estado' => $estado,
    'comentarios' => $comentarios
]);
