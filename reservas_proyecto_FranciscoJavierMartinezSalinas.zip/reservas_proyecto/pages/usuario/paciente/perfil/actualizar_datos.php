<?php
/*
 * Este script permite a un paciente actualizar su email y teléfono.
 * Verifica sesión y rol, valida los datos recibidos, actualiza la BD,
 * registra la acción en el log y redirige con mensajes de éxito o error.
 */
session_start();
include('../../../../includes/db.php');
include('../../../../includes/logger.php');

//Verificacion de seguridad, existe sesion 
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] != 'paciente') {
    header('Location: /reservas_proyecto/pages/public/login.php');
    exit();
}

$id_usuario = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');

    // Validar email y que teléfono no esté vacío
    if (filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($telefono)) {
        
        // Actualizar email y teléfono en la tabla usuarios para este paciente
        $stmt = $pdo->prepare("UPDATE usuarios SET email = ?, telefono = ? WHERE id_usuario = ?");
        $resultado = $stmt->execute([$email, $telefono, $id_usuario]);

        // Registrar acción en log
        $accion = "El paciente actualizó su perfil (email o teléfono)";
        registrarLog($pdo, $id_usuario, 'Edita_perfil', $accion);

        if ($resultado) {
            $_SESSION['mensaje_exito'] = "Datos actualizados correctamente.";
        } else {
            $_SESSION['mensaje_error'] = "Error al actualizar los datos. Inténtalo de nuevo.";
        }
    } else {
        // Validación fallida
        $_SESSION['mensaje_error'] = "Por favor, ingresa un email válido y teléfono.";
    }
} else {
    // Acceso inválido si no es POST
    $_SESSION['mensaje_error'] = "Acceso no permitido.";
}
// Redirigir a la página de edición de perfil, mostrando el mensaje
header('Location: editar_perfil.php');
exit();
