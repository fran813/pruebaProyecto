<?php
/*
 * Actualización de foto de perfil del paciente
 * Valida y procesa la subida de imagen, guarda el archivo y actualiza la base de datos.
 * Redirige con mensaje de éxito o error.
 */
session_start();
include('../../../../includes/db.php');

//Verificacion de seguridad, existe sesion 
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] != 'paciente') {
    header('Location: /reservas_proyecto/pages/public/login.php');
    exit();
}

// Guarda el ID del usuario en variable local
$id_usuario = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto'])) {
    $foto = $_FILES['foto'];

    // Comprueba que no haya errores en la subida y que sea un archivo de imagen
    if ($foto['error'] === UPLOAD_ERR_OK && strpos($foto['type'], 'image/') === 0) {
        // Extrae la extensión original del archivo
        $ext = pathinfo($foto['name'], PATHINFO_EXTENSION);
        // Genera un nuevo nombre para la foto con el ID del usuario
        $nuevoNombre = 'perfil_' . $id_usuario . '.' . $ext;
        // Define la ruta donde se guardará el archivo
        $ruta = '../../../../uploads/' . $nuevoNombre;

        // Mueve el archivo subido a la ruta definitiva
        if (move_uploaded_file($foto['tmp_name'], $ruta)) {
            // Actualiza en la base de datos el nombre del archivo para ese usuario
            $stmt = $pdo->prepare("UPDATE usuarios SET foto_perfil = ? WHERE id_usuario = ?");
            $stmt->execute([$nuevoNombre, $id_usuario]);

            // Mensaje de éxito para mostrar en el perfil
            $_SESSION['mensaje_exito'] = "Foto de perfil actualizada correctamente.";
        } else {
            $_SESSION['mensaje_error'] = "Error al subir la foto.";
        }
    } else {
        $_SESSION['mensaje_error'] = "Archivo no válido. Solo imágenes permitidas.";
    }
     // Redirige a la página de edición de perfil tras el proceso
    header('Location: editar_perfil.php');
    exit();
}
// Si no se recibió POST con foto, redirige igualmente a editar perfil
header('Location: editar_perfil.php');
exit();
?>
