<?php
/**
 * Devuelve en JSON las citas de un paciente dado su ID.
 * Recibe el ID por GET ('id') y retorna las citas ordenadas por fecha y hora descendente.
 * Usado para cargar el historial de citas vía AJAX.
 */
session_start();
include('../../../../includes/db.php');

// Comprobar que se ha recibido el parámetro 'id' vía GET
if (!isset($_GET['id'])) {
    echo json_encode([]);
    exit();
}

// Guardar el ID del paciente recibido
$paciente_id = $_GET['id'];

try {
    // Preparar consulta para obtener citas del paciente, ordenadas por fecha y hora descendente
    $sql = "SELECT id AS agenda_id, fecha, hora, estado 
            FROM agenda 
            WHERE paciente_id = ? 
            ORDER BY fecha DESC, hora DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$paciente_id]);
    $citas = $stmt->fetchAll(PDO::FETCH_ASSOC); // Obtener todas las citas como array asociativo

    // Establecer el tipo de contenido como JSON y devolver las citas
    header('Content-Type: application/json');
    echo json_encode($citas);
} catch (Exception $e) {
    // En caso de error, devolver un JSON con mensaje de error
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Error al obtener las citas.']);
}
