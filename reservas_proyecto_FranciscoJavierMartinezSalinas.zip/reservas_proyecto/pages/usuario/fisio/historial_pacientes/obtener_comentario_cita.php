<?php
include('../../../../includes/db.php');

// Verificar que se ha recibido el parámetro 'id' por GET
if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'ID no proporcionado']);
    exit();
}

// Guardar el ID de la cita recibido
$agenda_id = $_GET['id'];

try {
    // Preparar consulta para obtener comentarios relacionados con la cita ordenados por fecha descendente
    $sql = "SELECT comentario, fecha_comentario FROM comentarios_agenda WHERE agenda_id = ? ORDER BY fecha_comentario DESC";
    $stmt = $pdo->prepare($sql); // Preparar la consulta
    $stmt->execute([$agenda_id]); // Ejecutar con el id de la cita
    $comentarios = $stmt->fetchAll(PDO::FETCH_ASSOC); // Obtener todos los comentarios

    // Devolver los comentarios en formato JSON dentro de un array con clave 'comentarios'
    echo json_encode(['comentarios' => $comentarios]);
} catch (Exception $e) {
    // En caso de error devolver JSON con mensaje de error
    echo json_encode(['error' => 'Error al obtener los comentarios']);
}
