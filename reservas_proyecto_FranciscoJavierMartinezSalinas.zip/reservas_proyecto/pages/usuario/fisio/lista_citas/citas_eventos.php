<?php
// Obtiene y devuelve en JSON las citas del fisioterapeuta actual para mostrarlas en el calendario.

session_start();
include('../../../../includes/db.php');

// Definir que la respuesta será JSON
header('Content-Type: application/json');

// Obtener el ID del fisioterapeuta desde la sesión
$id_fisio = $_SESSION['user_id'];

// Preparar consulta para obtener las citas del fisioterapeuta junto con el nombre del paciente
$stmt = $pdo->prepare("SELECT a.id, a.fecha, a.hora, u.nombre AS nombre_paciente, a.estado
                       FROM agenda a
                       JOIN usuarios u ON a.paciente_id = u.id_usuario
                       WHERE a.fisioterapeuta_id = ?");
$stmt->execute([$id_fisio]);
$citas = $stmt->fetchAll(PDO::FETCH_ASSOC);

$eventos = []; // Inicializar arreglo para eventos que serán enviados
foreach ($citas as $cita) {
    $horaFormateada = date('H:i', strtotime($cita['hora']));
    $eventos[] = [
        'id' => $cita['id'],
        'title' => $horaFormateada . ' ' . $cita['nombre_paciente'],
        'start' => $cita['fecha'] . 'T' . $cita['hora'],
        'estado' => $cita['estado'],
    ];
}

// Enviar los eventos en formato JSON para que el frontend los use
echo json_encode($eventos);
?>