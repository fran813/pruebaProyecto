<?php
// Obtiene y devuelve en JSON los comentarios asociados a
//  una cita específica, ordenados por fecha ascendente.

include('../../../../includes/db.php');

// Verifica que se haya recibido el parámetro 'id' por GET, si no, devuelve un JSON vacío y termina
if (!isset($_GET['id'])) {
    echo json_encode([]);
    exit;
}

// Obtiene el ID de la cita desde el parámetro GET, asegurando que sea un entero
$cita_id = intval($_GET['id']);

// Prepara y ejecuta la consulta para obtener los comentarios de la cita ordenados por fecha ascendente
$stmt = $pdo->prepare("SELECT comentario, fecha_comentario FROM comentarios_agenda WHERE agenda_id = ? ORDER BY fecha_comentario ASC");
$stmt->execute([$cita_id]);

// Recupera todos los comentarios en un array asociativo
$comentarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Devuelve los comentarios en formato JSON
echo json_encode($comentarios);
?>
