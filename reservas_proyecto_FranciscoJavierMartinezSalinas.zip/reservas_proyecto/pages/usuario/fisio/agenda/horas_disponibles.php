<?php
session_start();
include('../../../../includes/db.php');

// Verifica si el usuario ha iniciado sesión y tiene el rol de fisioterapeuta
// Si no cumple estas condiciones, se bloquea el acceso con código 403 (Prohibido)
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] != 'fisioterapeuta') {
    http_response_code(403);
    exit;
}

// Obtiene la fecha desde la URL (parámetro GET), o null si no se proporciona
$fecha = $_GET['fecha'] ?? null;
$fisio_id = $_SESSION['user_id'];

// Si se ha recibido una fecha válida
if ($fecha) {
    // Prepara la consulta SQL para obtener todas las horas ya ocupadas
    // por el fisioterapeuta en la fecha seleccionada
    $sql = "SELECT hora FROM agenda WHERE fisioterapeuta_id = ? AND fecha = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$fisio_id, $fecha]);
    // Obtiene las horas ocupadas como un array, y recorta los segundos (HH:MM:SS → HH:MM)
    $horas_ocupadas = array_map(function($hora) {
        return substr($hora, 0, 5);
    }, $stmt->fetchAll(PDO::FETCH_COLUMN));
    
    // Devuelve el resultado como JSON
    echo json_encode($horas_ocupadas);
}
?>
