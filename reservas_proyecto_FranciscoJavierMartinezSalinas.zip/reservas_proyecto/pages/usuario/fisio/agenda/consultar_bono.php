<?php
/**
 * Devuelve en formato JSON la cantidad de bonos disponibles para un paciente dado.
 * Recibe el ID del paciente vía GET y consulta la base de datos.
 * Si no se recibe el ID, devuelve bono = 0.
 */
session_start();
include('../../../../includes/db.php');

// Verifica que se haya recibido el parámetro 'paciente_id' vía GET; si no, devuelve bono=0 en JSON y termina
if (!isset($_GET['paciente_id'])) {
    echo json_encode(['bono' => 0]);
    exit();
}

$paciente_id = intval($_GET['paciente_id']);

// Prepara y ejecuta la consulta para obtener la cantidad de bonos de ese paciente
$sql = "SELECT cantidad FROM bonos WHERE id_usuario = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$paciente_id]);
// Obtiene la cantidad de bonos
$bono = $stmt->fetchColumn();

// Devuelve la cantidad de bonos en formato JSON; si no hay bonos, devuelve 0
echo json_encode(['bono' => (int)$bono ?: 0]);
?>
